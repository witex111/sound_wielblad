﻿using System;
using System.IO;
using System.Runtime.InteropServices;
using GLFW;
using OpenTK;
using OpenTK.Audio.OpenAL;


using GlfwMonitor = GLFW.Monitor;
using SysExc = System.Exception;

namespace PMLabs
{
    public class BC : IBindingsContext
    {
        public IntPtr GetProcAddress(string procName)
            => Glfw.GetProcAddress(procName);
    }

    class Program
    {
        static KeyCallback kc = KeyProcessor;

        //  pola OpenAL:
        static ALDevice device;
        static ALContext context;
        static int buf;
        static int source;

        // ruch po okręgu:
        const float radius = 5f;
        static float angle = 0f;
        static float angularSpeed = 1f;
        const float angularAccel = 0.2f;
        static double lastTime;

        public static void KeyProcessor(IntPtr window, Keys key, int scanCode, InputState state, ModifierKeys mods)
        {
            if (key == Keys.Space && state == InputState.Press)
                AL.SourcePlay(source);
        }

        public static void InitSound()
        {
            //  Otwiercie urządzenia i tworzenie kontekst
            device = ALC.OpenDevice(null);
            if (device.Handle == IntPtr.Zero)
                throw new SysExc("Nie udało się otworzyć domyślnego urządzenia audio");

            context = ALC.CreateContext(device, new int[0]);
            ALC.MakeContextCurrent(context);

            //  Ustawienie słuchacza i Dopplera
            AL.Listener(ALListener3f.Position, 0f, 0f, 0f);
            AL.Listener(ALListener3f.Velocity, 0f, 0f, 0f);

            // orientacja: 
            float[] orient = new float[] { 0f, 0f, -1f, 0f, 1f, 0f };
            AL.Listener(ALListenerfv.Orientation, orient);

            AL.DopplerFactor(1.0f);
            AL.SpeedOfSound(343.3f);

            // wyłączanie tłumieninia odległości
            AL.DistanceModel(ALDistanceModel.None);

            //  Wczytanie pliku WAV
            string wavePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "camel.wav");
            if (!File.Exists(wavePath))
                throw new SysExc($"Nie znaleziono pliku: {wavePath}");

            int channels, bits, rate;
            byte[] data = LoadWave(wavePath, out channels, out bits, out rate);

            //  Geneerowanie bufora i ładowanie danych
            buf = AL.GenBuffer();
            var fmt = GetFormat(channels, bits);

            var handle = GCHandle.Alloc(data, GCHandleType.Pinned);
            try
            {
                IntPtr ptr = handle.AddrOfPinnedObject();
                AL.BufferData(buf, fmt, ptr, data.Length, rate);
            }
            finally
            {
                handle.Free();
            }

            // bufor 
            source = AL.GenSource();
            AL.Source(source, ALSourcei.Buffer, buf);
            AL.Source(source, ALSourceb.Looping, true);
            AL.Source(source, ALSourcef.Gain, 1.0f);

            //  sprawdzenie czy dzwiek dziala
            AL.SourcePlay(source);
            var state = AL.GetSourceState(source);
            Console.WriteLine("dzwiek dziala");

            lastTime = Glfw.Time;
        }

        public static void FreeSound()
        {
            AL.SourceStop(source);
            AL.DeleteSource(source);
            AL.DeleteBuffer(buf);

            ALC.DestroyContext(context);
            ALC.CloseDevice(device);
        }

        public static void SoundEvents()
        {
            double now = Glfw.Time;
            float dt = (float)(now - lastTime);
            lastTime = now;

            // przyśpieszenie kątowe 
            angularSpeed += angularAccel * dt;
            angle += angularSpeed * dt;
            if (angle > Math.PI * 2) angle -= (float)(Math.PI * 2);

            // pozycja po okręgu
            float x = radius * (float)Math.Cos(angle);
            float z = radius * (float)Math.Sin(angle);
            AL.Source(source, ALSource3f.Position, x, 0f, z);

            //  efekt Dopplera
            float vx = -radius * angularSpeed * (float)Math.Sin(angle);
            float vz = radius * angularSpeed * (float)Math.Cos(angle);
            AL.Source(source, ALSource3f.Velocity, vx, 0f, vz);
        }

        static void Main(string[] args)
        {
            Glfw.Init();
            var window = Glfw.CreateWindow(600, 600, "OpenAL wielblad dzwiek",
            GlfwMonitor.None, Window.None);
            Glfw.MakeContextCurrent(window);
            Glfw.SetKeyCallback(window, kc);

            try
            {
                InitSound();
                while (!Glfw.WindowShouldClose(window))
                {
                    SoundEvents();
                    Glfw.PollEvents();
                }
            }
            catch (SysExc ex)
            {
                Console.WriteLine("Błąd audio: " + ex.Message);
            }
            finally
            {
                FreeSound();
                Glfw.Terminate();
            }
        }

        // metoda pomocnicza
        static ALFormat GetFormat(int channels, int bits) => channels switch
        {
            1 => bits == 8 ? ALFormat.Mono8 : ALFormat.Mono16,
            2 => bits == 8 ? ALFormat.Stereo8 : ALFormat.Stereo16,
            _ => throw new System.NotSupportedException("Tylko mono/stereo")
        };

        static byte[] LoadWave(string path, out int channels, out int bits, out int rate)
        {
            using var br = new BinaryReader(File.Open(path, FileMode.Open));
            if (new string(br.ReadChars(4)) != "RIFF") throw new System.NotSupportedException();
            br.ReadInt32();
            if (new string(br.ReadChars(4)) != "WAVE") throw new System.NotSupportedException();
            if (new string(br.ReadChars(4)) != "fmt ") throw new System.NotSupportedException();
            int sub = br.ReadInt32();
            br.ReadInt16();
            channels = br.ReadInt16();
            rate = br.ReadInt32();
            br.ReadInt32();
            br.ReadInt16();
            bits = br.ReadInt16();
            if (sub > 16) br.ReadBytes(sub - 16);
            while (new string(br.ReadChars(4)) != "data")
            {
                int sz = br.ReadInt32();
                br.ReadBytes(sz);
            }
            int dataSize = br.ReadInt32();
            return br.ReadBytes(dataSize);
        }
    }
}
